const menu=document.getElementById("menu"),nav=document.getElementById("nav");
menu.onclick=()=>{nav.classList.toggle("open");menu.textContent=nav.classList.contains("open")?"✕":"☰"};
document.querySelectorAll("nav a").forEach(a=>a.onclick=()=>{nav.classList.remove("open");menu.textContent="☰"});
const top=document.getElementById("top");
window.addEventListener("scroll",()=>top.classList.toggle("show",scrollY>450));
top.onclick=()=>scrollTo({top:0,behavior:"smooth"});
document.getElementById("contactForm").onsubmit=e=>{e.preventDefault();document.getElementById("sent").textContent="ধন্যবাদ! আপনার বার্তা গ্রহণ করা হয়েছে।";e.target.reset()};
document.getElementById("year").textContent=new Date().getFullYear();
